<?
	$page_title = "Message Management System";
?>